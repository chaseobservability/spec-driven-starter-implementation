# ADR-0001: <Decision Title>

- Status: Proposed | Accepted | Deprecated
- Date: 2026-02-11
- Authors: <name(s)>
- Related: <links/issues/PRs>

## Context
What problem are we solving? What constraints matter?

## Decision
What are we doing? Keep it concise and specific.

## Alternatives Considered
- Option A: ...
- Option B: ...

## Consequences
### Positive
- ...

### Negative / Risks
- ...

## Follow-ups
- [ ] ...
