# Changelog

## 0.1.0 — 2026-02-11
- Initial starter implementation repo (spec pinning + CI + governance)
