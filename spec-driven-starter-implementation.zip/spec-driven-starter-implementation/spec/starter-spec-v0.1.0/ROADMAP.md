# Roadmap — Starter Spec Repo

## Current
### v0.1.0 (2026-02-11)
- Baseline contract artifacts + CI + governance docs

## Next
- Expand examples (more schemas, more flows)
- Add stronger contract validation (OpenAPI/schema validators)
- Add automated changelog checks
