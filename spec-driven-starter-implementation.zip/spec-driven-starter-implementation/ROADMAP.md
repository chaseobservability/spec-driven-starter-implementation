# Roadmap — Starter Implementation Repo

## Current
### v0.1.0 (2026-02-11)
- Baseline spec pinning + CI + governance docs

## Next
- Add a minimal service skeleton
- Add contract tests (OpenAPI response validation)
- Add executable flow runner
